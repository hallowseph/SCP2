package scp2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author hallowseph(xxg8089), Nicolas-Kotze (RTH8619)
 */
public class ExitAction implements ActionListener{

    @Override
    public void actionPerformed(ActionEvent e) {
        System.exit(0);
    }
}
