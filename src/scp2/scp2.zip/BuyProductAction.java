package scp2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author hallowseph(xxg8089), Nicolas-Kotze (RTH8619)
 *
 */
public class BuyProductAction implements ActionListener {

    private Connection connection;
    private JTextArea textArea;
    private String userInput;

    public BuyProductAction(Connection connection, JTextArea textArea) {
        this.connection = connection;
        this.textArea = textArea;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            //get user input for the product name or ID to buy more of
            String productIdStr = JOptionPane.showInputDialog("Enter Product ID or Name to buy more of:");
            if (productIdStr == null || productIdStr.isEmpty()) {
                //if user cancels input or enters an empty value
                return;
            }

            //check if the entered value is a product ID or a name
            int productId = -1;
            boolean isProductId = false;

            try {
                productId = Integer.parseInt(productIdStr);
                isProductId = true;
            } catch (NumberFormatException ex) {
                //
            }

            //find the product in the DB
            String query;
            if (isProductId) {
                query = "SELECT * FROM Products WHERE Product_ID = ?";
            } else {
                query = "SELECT * FROM Products WHERE Product_Name = ?";
            }
            

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, productIdStr);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                //product exists, get the current quantity and proceed to update it
                int existingQuantity = resultSet.getInt("Quantity");
                preparedStatement.close();

                //get the quantity to buy
                String quantityStr = JOptionPane.showInputDialog("Enter the quantity to buy:");
                if (quantityStr == null || quantityStr.isEmpty()) {
                    //if user cancels or enters an empty value
                    return;
                }

                int quantityToAdd;
                try {
                    quantityToAdd = Integer.parseInt(quantityStr);
                    if (quantityToAdd <= 0) {
                        JOptionPane.showMessageDialog(null, "Quantity must be greater than 0.");
                        return;
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid integer for quantity.");
                    return;
                }

                int newQuantity = existingQuantity + quantityToAdd;

                //update the quantity in the DB
                String updateQuery = "UPDATE Products SET Quantity = ? WHERE ";
                if (isProductId) {
                    updateQuery += "Product_ID = ?";
                } else {
                    updateQuery += "Product_Name = ?";
                }

                PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
                updateStatement.setInt(1, newQuantity);
                updateStatement.setString(2, productIdStr);
                updateStatement.executeUpdate();
                updateStatement.close();

                //Call the DisplayStockAction to refresh the display
                DisplayStockAction displayStockAction = new DisplayStockAction(textArea);
                displayStockAction.actionPerformed(null);//Pass a dummy action event to trigger the refresh to all buttons except the display button.

                //display success message
                JOptionPane.showMessageDialog(null, "Product quantity updated successfully!");

            } else {
                //if product does not exist
                JOptionPane.showMessageDialog(null, "Product not found in the inventory.");
            }
        } catch (NumberFormatException | SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: Unable to update product quantity. Please check your input.");
        }
    }
    public void setUserInput(String userInput) {
        this.userInput = userInput;
    }
    
    public String getUserInput() {
    	return this.userInput; 
    }
    
    public void actionPerformed() {
        try {
            String userInput = getUserInput();

            if (userInput == null || userInput.isEmpty()) {
                textArea.append("Invalid input. Please provide a product ID and quantity.\n");
                return;
            }

            String[] inputParts = userInput.split(",");
            if (inputParts.length != 2) {
                textArea.append("Invalid input format. Please provide a product ID and quantity separated by a comma.\n");
                return;
            }

            int productID;
            int quantity;

            try {
                productID = Integer.parseInt(inputParts[0]);
                quantity = Integer.parseInt(inputParts[1]);
            } catch (NumberFormatException e) {
                textArea.append("Invalid input format. Please provide valid integers for product ID and quantity.\n");
                return;
            }

            String updateQuery = "UPDATE Products SET Quantity = Quantity + ? WHERE Product_ID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setInt(1, quantity);
            preparedStatement.setInt(2, productID);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                textArea.append(quantity + " units of product with ID " + productID + " bought successfully.\n");
            } else {
                textArea.append("No product found with ID " + productID + ".\n");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            textArea.append("Error occurred while buying the product.\n");
        }
    }
}
