package scp2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author hallowseph(xxg8089), Nicolas-Kotze (RTH8619)
 */
public class RemoveProductAction implements ActionListener {

    private Connection connection;
    private JTextArea textArea;
    private String userInput; // Store user input

    public RemoveProductAction(Connection connection, JTextArea textArea) {
        this.connection = connection;
        this.textArea = textArea;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //prompt the user for the product ID or name to remove
        String userInput = JOptionPane.showInputDialog("Enter the product ID or name to remove:");
        if (userInput == null || userInput.isEmpty()) {
            //if user cancels or enters an empty value
            return;
        }

        try {
            //check if the product exists in the DB based on ID or name
            String query = "SELECT * FROM Products WHERE Product_ID = ? OR Product_Name = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            int productId;
            try {
                //attempt to parse the input as an integer (product ID)
                productId = Integer.parseInt(userInput);
                preparedStatement.setInt(1, productId);
                preparedStatement.setString(2, "");//empty string for product name
            } catch (NumberFormatException ex) {
                //if parsing as an integer fails, treat it as a product name
                productId = 0;
                preparedStatement.setInt(1, productId);
                preparedStatement.setString(2, userInput);
            }

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                //if product exists, remove it from the DB
                String productName = resultSet.getString("Product_Name");
                preparedStatement.close();

                //execute DELETE statement
                String deleteQuery = "DELETE FROM Products WHERE Product_ID = ? OR Product_Name = ?";
                PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery);
                deleteStatement.setInt(1, productId);
                deleteStatement.setString(2, productName);
                deleteStatement.executeUpdate();
                deleteStatement.close();

                //Call the DisplayStockAction to refresh the display
                DisplayStockAction displayStockAction = new DisplayStockAction(textArea);
                displayStockAction.actionPerformed(null);//Pass a dummy action event to trigger the refresh to all buttons except the display button.

                //display success message
                JOptionPane.showMessageDialog(null, "Product '" + productName + "' removed successfully!");

            } else {
                //product does not exist
                preparedStatement.close();
                JOptionPane.showMessageDialog(null, "Product not found in the inventory.");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: Unable to remove the product. Please check your input.");
        }
    }
    
    // Add a method to set user input
    public void setUserInput(String userInput) {
        this.userInput = userInput;
    }
    
    public String getUserInput() {
    	return this.userInput; 
    }
    
    public void actionPerformed() {
        try {
            String userInput = getUserInput();

            if (userInput == null || userInput.isEmpty()) {
                textArea.append("Invalid input. Please provide a product ID.\n");
                return;
            }

            int productID;

            try {
                productID = Integer.parseInt(userInput);
            } catch (NumberFormatException e) {
                textArea.append("Invalid input format. Please provide a valid product ID.\n");
                return;
            }

            String deleteQuery = "DELETE FROM Products WHERE Product_ID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery);
            preparedStatement.setInt(1, productID);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                textArea.append("Product with ID " + productID + " removed successfully.\n");
            } else {
                textArea.append("No product found with ID " + productID + ".\n");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            textArea.append("Error occurred while removing the product.\n");
        }
    }
}
