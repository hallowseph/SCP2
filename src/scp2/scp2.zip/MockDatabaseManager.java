package scp2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class MockDatabaseManager {
    public static Connection getMockConnection() throws SQLException {
        String dbURL = "jdbc:derby:MockInventoryDB;create=true";
        
        Connection connection = DriverManager.getConnection(dbURL);
        Statement statement = connection.createStatement();
        
        // Create a mock table
        String createTableSQL = "CREATE TABLE Products ("
                + "Product_ID INT PRIMARY KEY, "
                + "Product_Name VARCHAR(255), "
                + "Product_Type VARCHAR(255), "
                + "Price DECIMAL(10, 2), "
                + "Quantity INT"
                + ")";
        statement.executeUpdate(createTableSQL);
        
        return connection;
    }
}
