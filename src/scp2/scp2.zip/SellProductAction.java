package scp2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author hallowseph(xxg8089), Nicolas-Kotze (RTH8619)
 */
public class SellProductAction implements ActionListener {

    private Connection connection;
    private JTextArea textArea;
    private String userInput; // Store user input

    public SellProductAction(Connection connection, JTextArea textArea) {
        this.connection = connection;
        this.textArea = textArea;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            //get user input for the product name or ID to sell
            String productIdStr = JOptionPane.showInputDialog("Enter Product ID or Name to sell:");
            if (productIdStr == null || productIdStr.isEmpty()) {
                //if user cancels or enters an empty value
                return;
            }

            //check if the entered value is a numeric product ID or a name
            int productId = -1;
            boolean isProductId = false;

            try {
                productId = Integer.parseInt(productIdStr);
                isProductId = true;
            } catch (NumberFormatException ex) {
                //
            }

            //find the existing product in the DB
            String query;
            if (isProductId) {
                query = "SELECT * FROM Products WHERE Product_ID = ?";
            } else {
                query = "SELECT * FROM Products WHERE Product_Name = ?";
            }

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, productIdStr);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                //product exists, get the current quantity and proceed to sell
                int existingQuantity = resultSet.getInt("Quantity");
                preparedStatement.close();

                //get the quantity to sell
                String quantityStr = JOptionPane.showInputDialog("Enter the quantity to sell");
                if (quantityStr == null || quantityStr.isEmpty()) {
                    //if user cancels or enters an empty value
                    return;
                }

                int quantityToSell;
                try {
                    quantityToSell = Integer.parseInt(quantityStr);
                    if (quantityToSell <= 0 || quantityToSell > existingQuantity) {
                        JOptionPane.showMessageDialog(null, "Invalid quantity to sell.");
                        return;
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid integer for quantity.");
                    return;
                }

                int newQuantity = existingQuantity - quantityToSell;

                //update the quantity in the DB
                String updateQuery = "UPDATE Products SET Quantity = ? WHERE ";
                if (isProductId) {
                    updateQuery += "Product_ID = ?";
                } else {
                    updateQuery += "Product_Name = ?";
                }

                PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
                updateStatement.setInt(1, newQuantity);
                updateStatement.setString(2, productIdStr);
                updateStatement.executeUpdate();
                updateStatement.close();

                //Call the DisplayStockAction to refresh the display
                DisplayStockAction displayStockAction = new DisplayStockAction(textArea);
                displayStockAction.actionPerformed(null);//Pass a dummy action event to trigger the refresh to all buttons except the display button.

                //display success message
                JOptionPane.showMessageDialog(null, "Product quantity updated successfully!");

            } else {
                JOptionPane.showMessageDialog(null, "Product not found in the iunventory.");
            }
        } catch (NumberFormatException | SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: Unable to update product quantity. Please check your input.");
        }
    }
    
    // Add a method to set user input
    public void setUserInput(String userInput) {
        this.userInput = userInput;
    }
    
    public String getUserInput() {
    	return this.userInput; 
    }
    
    public void actionPerformed() {
        try {
            String userInput = getUserInput();

            if (userInput == null || userInput.isEmpty()) {
                textArea.append("Invalid input. Please provide a product ID and quantity.\n");
                return;
            }

            String[] inputParts = userInput.split(",");
            if (inputParts.length != 2) {
                textArea.append("Invalid input format. Please provide a product ID and quantity separated by a comma.\n");
                return;
            }

            int productID;
            int quantity;

            try {
                productID = Integer.parseInt(inputParts[0]);
                quantity = Integer.parseInt(inputParts[1]);
            } catch (NumberFormatException e) {
                textArea.append("Invalid input format. Please provide valid integers for product ID and quantity.\n");
                return;
            }

            String updateQuery = "UPDATE Products SET Quantity = Quantity - ? WHERE Product_ID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(updateQuery);
            preparedStatement.setInt(1, quantity);
            preparedStatement.setInt(2, productID);

            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                textArea.append(quantity + " units of product with ID " + productID + " sold successfully.\n");
            } else {
                textArea.append("No product found with ID " + productID + ".\n");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            textArea.append("Error occurred while selling the product.\n");
        }
    }
}
