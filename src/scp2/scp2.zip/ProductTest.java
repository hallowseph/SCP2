package scp2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProductTest {

    @Test
    void testGettersAndSetters() {
        Product product = new Product(1, "TestProduct", "TestType", 10.0, 100);
        
        assertEquals(1, product.getProductID());
        assertEquals("TestProduct", product.getProductName());
        assertEquals("TestType", product.getProductType());
        assertEquals(10.0, product.getPrice());
        assertEquals(100, product.getQuantity());
        
        // Test setters
        product.setProductID(2);
        product.setProductName("UpdatedProduct");
        product.setProductType("UpdatedType");
        product.setPrice(20.0);
        product.setQuantity(200);
        
        assertEquals(2, product.getProductID());
        assertEquals("UpdatedProduct", product.getProductName());
        assertEquals("UpdatedType", product.getProductType());
        assertEquals(20.0, product.getPrice());
        assertEquals(200, product.getQuantity());
    }
}
