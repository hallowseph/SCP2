package scp2;

import org.junit.jupiter.api.Test;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JTextArea;

import static org.junit.jupiter.api.Assertions.*;

class AddProductActionTest {

    @Test
    void testActionPerformed() throws SQLException {
        Connection mockConnection = MockDatabaseManager.getMockConnection();
        mockConnection.setAutoCommit(false); // Begin transaction

        try {
            // Create a mock connection and textArea
            JTextArea mockTextArea = new JTextArea();

            AddProductAction addProductAction = new AddProductAction(mockConnection, mockTextArea);

            // Prepare test data
            String[] testData = {"TestProduct", "TestType", "10.0", "100"};

            // Perform action
            addProductAction.actionPerformed(testData);

            // Verify the product was added
            PreparedStatement preparedStatement = mockConnection.prepareStatement("SELECT * FROM Products WHERE Product_Name = ?");
            preparedStatement.setString(1, "TestProduct");
            assertTrue(preparedStatement.executeQuery().next());

            // If the test completes without any exceptions, you can commit the transaction
            mockConnection.commit();
        } catch (Exception e) {
            // If an exception occurs during the test, you can rollback the transaction to undo any changes
            mockConnection.rollback();
            fail("Test failed with exception: " + e.getMessage());
        } finally {
            // Always close the connection
            mockConnection.close();
        }
    }
}


