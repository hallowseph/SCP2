package scp2;

/**
 *
 * @author xxg8089,rth8619
 */

// enum for possible transaction types, ensure these are the only two transaction types
public enum TransactionType {
    BUY,
    SELL
}
